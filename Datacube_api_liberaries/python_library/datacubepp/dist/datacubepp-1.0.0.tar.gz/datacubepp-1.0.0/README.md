# DataCubePP

DataCubePP is a Python client for interacting with a backend API designed for managing databases and collections, featuring robust CRUD operations, metadata retrieval, and input validation.

## Features

- Perform CRUD operations on databases and collections.
- Manage metadata for databases and collections.
- Comprehensive input validation for better error handling.
- Designed with extensibility and maintainability in mind.

## Installation

Install the package via pip:

```bash
pip install datacubepp
```

## Requirements

Ensure the following dependencies are installed:

- Python >= 3.7
- `requests`
- `pymongo`
- `pydantic`

## Usage

Here's an example of how to use the DataCubePP client:

```python
from datacubepp.client import APIClient

# Initialize the client
client = APIClient(api_key="your_api_key")

# List all databases
try:
    response = client.list_databases()
    print(response)
except Exception as e:
    print(f"Error: {e}")

# Create a new database with collections
try:
    db_name = "test_database"
    collections = [
        {"name": "users", "fields": [{"name": "username", "type": "string"}]},
        {"name": "products", "fields": [{"name": "product_name", "type": "string"}]},
    ]
    response = client.create_database(db_name, collections)
    print(response)
except Exception as e:
    print(f"Error: {e}")
```

## Development

1. Clone the repository.
2. Install dependencies using `pip install -r requirements.txt`.
3. Run tests using `pytest`.

## Tests

Run the tests to ensure everything is working:

```bash
pytest
```

## Contributing

We welcome contributions to DataCubePP! To contribute:

1. Fork the repository.
2. Create a new branch.
3. Commit your changes.
4. Submit a pull request.

## License

DataCubePP is licensed under the MIT License. See `LICENSE` for more details.

## Support

If you encounter any issues or have questions, feel free to open an issue on [GitHub](https://github.com/your-repo/datacubepp).

---

Happy coding!
