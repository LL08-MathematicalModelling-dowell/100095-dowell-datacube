# Development

### Setup
To set up the development environment:

1. Clone the repository:
   ```bash
   git clone https://github.com/your-repo/mypackage.git
   ```
2. Navigate to the project directory:
   ```bash
   cd mypackage
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### Testing
Run the tests using `pytest`:
```bash
pytest
```

### Contributing Guidelines
- Fork the repository.
- Create a new branch for your feature or bug fix.
- Write unit tests for any new features.
- Submit a pull request with a detailed description of your changes.

---
