# APIClient Documentation

## Overview

The `APIClient` package offers a Python interface for interacting with a backend API for database and collection management. This documentation outlines usage examples, features, and development guidelines.

---

## Table of Contents

1. [Introduction](#introduction)
2. [Usage Guide](#usage-guide)
   - [Installation](#installation)
   - [Initialization](#initialization)
   - [Methods Overview](#methods-overview)
   - [Examples](#examples)
3. [Development](#development)
   - [Setup](#setup)
   - [Testing](#testing)
   - [Contributing Guidelines](#contributing-guidelines)

---

# Introduction

The `APIClient` simplifies interaction with an API by providing structured methods for CRUD operations on databases and collections. The package includes input validation, error handling, and a streamlined API integration experience.

---

# Usage Guide

### Installation

To install the package, use pip:

```bash
pip install datacubepp
```

### Initialization

```python
from datacubepp.client import APIClient

# Initialize the APIClient
client = APIClient(api_key="your_api_key")
```

### Methods Overview

#### 1. `create_database`

Create a new database with specified collections.

```python
response = client.create_database(
    db_name="test_db",
    collections=[{"name": "users", "fields": [{"name": "username", "type": "string"}]}]
)
print(response)
```

#### 2. `list_databases`

List all databases.

```python
response = client.list_databases()
print(response)
```

#### 3. `create_collection`

Add a collection to a database.

```python
response = client.create_collection(
    database_id="database_id",
    collection_name="products",
    fields=[{"name": "product_name", "type": "string"}]
)
print(response)
```

#### 4. `read`

Fetch documents from a collection.

```python
response = client.read(
    database_id="database_id",
    collection_name="users",
    filters={"is_deleted": False},
    limit=10
)
print(response)
```

#### 5. `update`

Update documents in a collection.

```python
response = client.update(
    database_id="database_id",
    collection_name="users",
    filters={"username": "john_doe"},
    update_data={"email": "new_email@example.com"}
)
print(response)
```

#### 6. `delete`

Delete documents from a collection.

```python
response = client.delete(
    database_id="database_id",
    collection_name="users",
    filters={"username": "john_doe"},
    soft_delete=True
)
print(response)
```

#### 7. `get_metadata`

Retrieve metadata for a database.

```python
response = client.get_metadata(database_id="database_id")
print(response)
```

---

# Development

### Setup

To set up the development environment:

1. Clone the repository:
   ```bash
   git clone https://github.com/your-repo/mypackage.git
   ```
2. Navigate to the project directory:
   ```bash
   cd mypackage
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### Testing

Run the tests using `pytest`:

```bash
pytest
```

### Contributing Guidelines

- Fork the repository.
- Create a new branch for your feature or bug fix.
- Write unit tests for any new features.
- Submit a pull request with a detailed description of your changes.

---
