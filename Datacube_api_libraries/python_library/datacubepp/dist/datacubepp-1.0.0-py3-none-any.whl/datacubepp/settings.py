class Config:
    BASE_URL: str = "http://127.0.0.1:8000"
    API_KEY: str | None = None
    TIMEOUT: int = 5
    RETRIES: int = 3
