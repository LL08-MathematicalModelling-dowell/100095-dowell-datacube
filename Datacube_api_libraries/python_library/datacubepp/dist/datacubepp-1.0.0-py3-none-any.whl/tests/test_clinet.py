""" Tests for the API client. """

from unittest.mock import patch, MagicMock
import pytest
from datacubepp.client import APIClient
from datacubepp.exceptions import ValidationError, APIError

BASE_URL = "http://localhost:8000"
API_KEY = "test_api_key"

@pytest.fixture
def client():
    """Fixture to initialize the API client."""
    return APIClient(base_url=BASE_URL, api_key=API_KEY)

@patch("requests.Session.request")
def test_create_database_success(mock_request, api_client):
    """Test creating a database successfully."""
    mock_request.return_value = MagicMock(
        status_code=201,
        json=lambda: {"success": True, "message": "Database created successfully."}
    )

    response = api_client.create_database(
        "test_db", 
        [
            {"name": "users", "fields": [{"name": "username", "type": "string"}]}
        ])
    assert response["success"] is True
    assert response["message"] == "Database created successfully."
    mock_request.assert_called_once()

@patch("requests.Session.request")
def test_create_database_validation_error(mock_request, api_client):
    """Test validation error when creating a database."""
    with pytest.raises(ValidationError):
        api_client.create_database("", [])

    mock_request.assert_not_called()

@patch("requests.Session.request")
def test_create_database_http_error(mock_request, api_client):
    """Test HTTP error during database creation."""
    mock_request.return_value = MagicMock(
        status_code=400,
        json=lambda: {"success": False, "message": "Bad request."}
    )

    with pytest.raises(APIError) as exc_info:
        api_client.create_database(
            "test_db", 
            [
                {"name": "users", "fields": [{"name": "username", "type": "string"}]}
            ]
        )

    assert "HTTP 400" in str(exc_info.value)
    mock_request.assert_called_once()

@patch("requests.Session.request")
def test_list_databases_success(mock_request, api_client):
    """Test listing databases successfully."""
    mock_request.return_value = MagicMock(
        status_code=200,
        json=lambda: {"success": True, "data": ["db1", "db2"]}
    )

    response = api_client.list_databases()
    assert response["success"] is True
    assert "db1" in response["data"]
    mock_request.assert_called_once()

@patch("requests.Session.request")
def test_list_databases_http_error(mock_request, api_client):
    """Test HTTP error during listing databases."""
    mock_request.return_value = MagicMock(
        status_code=500,
        json=lambda: {"success": False, "message": "Internal server error."}
    )

    with pytest.raises(APIError) as exc_info:
        api_client.list_databases()

    assert "HTTP 500" in str(exc_info.value)
    mock_request.assert_called_once()